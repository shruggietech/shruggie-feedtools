"""GUI application."""
